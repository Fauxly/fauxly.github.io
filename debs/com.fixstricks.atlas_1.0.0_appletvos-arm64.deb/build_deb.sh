#!/bin/bash
set -e

# Запускать из корня atlas-deb/ на macOS.
# Предварительно нужно:
#   1. Собрать Atlas.app в Xcode для appletvos-arm64 (архивная сборка, не симулятор)
#   2. Скопировать содержимое .app в Applications/Atlas.app/, ЗАМЕНИВ существующие файлы,
#      но НЕ удаляя Entitlements-Privileged.plist — он должен остаться внутри бандла:
#
#      rsync -a --exclude 'Entitlements-Privileged.plist' \
#          /path/to/DerivedData/.../Atlas.app/ Applications/Atlas.app/
#
#   3. Наличие dpkg-deb: на macOS ставится через `brew install dpkg`

PACKAGE_ROOT="$(cd "$(dirname "$0")" && pwd)"
OUTPUT_DEB="$PACKAGE_ROOT/com.fixstricks.atlas_1.0.0_appletvos-arm64.deb"

if ! command -v dpkg-deb >/dev/null 2>&1; then
    echo "dpkg-deb не найден. Установи через: brew install dpkg"
    exit 1
fi

if [ ! -f "$PACKAGE_ROOT/Applications/Atlas.app/Atlas" ]; then
    echo "ОШИБКА: не найден бинарник $PACKAGE_ROOT/Applications/Atlas.app/Atlas"
    echo "Сначала скопируй туда собранный .app из Xcode (см. комментарии в начале скрипта)."
    exit 1
fi

echo "Выставляем права на maintainer-скрипты..."
chmod 0755 "$PACKAGE_ROOT/DEBIAN/postinst"
chmod 0755 "$PACKAGE_ROOT/DEBIAN/prerm"

echo "Выставляем права на содержимое пакета..."
find "$PACKAGE_ROOT/Applications" -type d -exec chmod 0755 {} \;
find "$PACKAGE_ROOT/Applications" -type f -exec chmod 0644 {} \;
chmod 0755 "$PACKAGE_ROOT/Applications/Atlas.app/Atlas"

echo "Собираем .deb..."
dpkg-deb --build --root-owner-group "$PACKAGE_ROOT" "$OUTPUT_DEB"

echo "Готово: $OUTPUT_DEB"
echo "Установка на устройстве (через SSH или Filza):"
echo "  dpkg -i $(basename "$OUTPUT_DEB")"
